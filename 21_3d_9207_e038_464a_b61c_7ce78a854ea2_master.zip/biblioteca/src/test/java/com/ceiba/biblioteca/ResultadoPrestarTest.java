package com.ceiba.biblioteca;

public class ResultadoPrestarTest {
    private int id;
    private String fechaMaximaDevolucion;

    public int getId() {
        return id;
    }

    public String getFechaMaximaDevolucion() {
        return fechaMaximaDevolucion;
    }

    public void setFechaMaximaDevolucion(String fechaMaximaDevolucion) {
        this.fechaMaximaDevolucion = fechaMaximaDevolucion;
    }

    public void setId(int id) {
        this.id = id;
    }
}
